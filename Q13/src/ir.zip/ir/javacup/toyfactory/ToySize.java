package ir.javacup.toyfactory;

public enum ToySize {
    SMALL, MEDIUM, LARGE
}
