package ir.javacup.shop;

public class Pants extends Clothing {

	public Pants(String name, Season season, long basePrice) {
		super(name, season, basePrice);
	}

}
