package ir.javacup.shop;

public enum Season {

	SPRING, SUMMER, FALL, WINTER
	
}
