package ir.javacup.shop;

public class Shirt extends Clothing {

	public Shirt(String name, Season season, long basePrice) {
		super(name, season, basePrice);
	}

}
