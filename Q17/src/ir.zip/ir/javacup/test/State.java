package ir.javacup.test;

public enum State {
    SECURE, INSECURE
}
