package ir.javacup.reflection;


import java.lang.reflect.Field;

public class Copier {

	String[] params;

	public Copier (String... params) {
		this.params = params;
	}
	
	public void copy(Object o1, Object o2) {
		Field[] o1Fields = o1.getClass().getFields();
		Field[] o2Fields = o2.getClass().getFields();

		if (params.length ==  0) {
			for (int i = 0; i < o1Fields.length; i++) {
				try {
					Object value = o1Fields[i].get(o1);
					o2Fields[i].set(o2, value);
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}

			}
		} else {
			for (String param : params) {
				for (int i = 0; i < o1Fields.length; i++) {
					String name = o1Fields[i].getName();
					if (param.equals(name)) {
						try {
							Object value = o1Fields[i].get(o1);
							o2Fields[i].set(o2, value);
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						}
					}

				}
			}
		}


	}

//	public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException {
//
//		Copier copier = new Copier();
//		Circle c1 = new Circle(5.5, 8);
//		Circle c2 = new Circle();
//
//		System.out.println(c1.getRadius());
//		System.out.println(c2.getRadius());
//		System.out.println(c1.getA());
//		System.out.println(c2.getA());
//		copier.copy(c1, c2);
//		System.out.println(c1.getRadius());
//		System.out.println(c2.getRadius());
//		System.out.println(c1.getA());
//		System.out.println(c2.getA());
//
//		Circle circle = new Circle();
//		circle.radius = 2.5;
//		Class circleClass =
//				Class.forName("ir.javacup.reflection.Circle");
//		Field[] fields = circleClass.getFields();
//
//		System.out.println(circle.getClass().getFields()[0]);
//		for (Field field : fields)
//			if(field.getName().equals("radius")){
//				Object value = field.get(circle);
//				Double r = (Double) value;
//				System.out.println(r);
//				field.set(circle, r*2);
//				System.out.println(circle.radius);
//			}
//	}
}
